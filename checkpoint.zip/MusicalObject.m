classdef MusicalObject < handle
    
    properties
        Image
        BoundingBox
        Label
        
    end
    
    methods
        function obj = MusicalObject(image, bb, label)
            obj.Image = image;
            obj.BoundingBox = bb;
            obj.Label = label;
        end
    end
end

